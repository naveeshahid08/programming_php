<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link href="../../css/styles.css" rel="stylesheet">
    <title>PHP &amp; My SQL : Section A Intro</title>
  </head>
  <body>
    <a href="../../index.php">PHP &amp; MySQL</a>
    <h2>Section A Intro</h2>
    <table>
      <tr><th>Page</th><th>Title</th><th>Filename</th></tr>
      <tr><td>21</td><td class="title">Test page</b></td><td class="link"><a href="test.php">test.php</a></td></tr>
      <tr><td>25</td><td class="title">Echo Statement</b></td><td class="link"><a href="echo.php">echo.php</a></td></tr>
      <tr><td>26</td><td class="title">Comments</b></td><td class="link"><a href="comments.php">comments.php</a></td></tr>
    </table>
  </body>
</html>