    <footer>
      <div class="container">
        &copy; Creative Folk <?= date('Y'); ?>
      </div>
    </footer>
    <script src="../js/site.js"></script>
  </body>
</html>