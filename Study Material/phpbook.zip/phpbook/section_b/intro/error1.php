<?php
echo $name;
echo ' welcome to our site.';
?>