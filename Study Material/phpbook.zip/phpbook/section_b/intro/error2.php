<?php
echo 'Hello ';
username = 'Ivy';
?>