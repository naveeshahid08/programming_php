<?php
define('SITE_NAME', 'Mountain Art Supplies');
const ADMIN_EMAIL = 'admin@eg.link';