<?php $basket = new Basket(); ?>
<h1>Basket</h1>