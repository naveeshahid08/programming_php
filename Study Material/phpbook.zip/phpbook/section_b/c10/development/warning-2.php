<?php $list = false; ?>
<h1>Basket</h1>
<?php foreach ($list as $item) { ?>
    Item: <?= $item ?><br>
<?php } ?>