<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link href="../../css/styles.css" rel="stylesheet">
    <title>Chapter 7: Images and Files</title>
  </head>
  </body>
    <a href="../../index.php">PHP &amp; MySQL</a>
    <h2>Chapter 7: Images and Files</h2>
    <p>The examples for this chapter are available in the code download.</p>
  </body>
</html>